package Hitoo; // Define un paquete llamado Hitoo

import java.sql.*; // Importa las clases necesarias para interactuar con bases de datos SQL
import java.util.Scanner; // Importa la clase Scanner para leer la entrada del usuario

public class Menu { // Define una clase llamada Menu

    public static void main(String[] args) { // El punto de entrada de la aplicación

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hito", "root", "")) { // Intenta conectarse a una base de datos MySQL llamada "hito" en localhost, usando el usuario "root" y una contraseña vacía

            ProductoDAO productoDAO = new ProductoDAO(con); // Crea un objeto ProductoDAO para interactuar con la base de datos
            Scanner scanner = new Scanner(System.in); // Crea un objeto Scanner para leer la entrada del usuario

            while (true) { // Un bucle infinito que muestra el menú y espera la entrada del usuario

                System.out.println("\nMenú:"); // Imprime el menú en la consola
                System.out.println("1. Añadir producto");
                System.out.println("2. Ver productos");
                System.out.println("3. Eliminar producto");
                System.out.println("4. Actualizar producto");
                System.out.println("5. Salir");
                System.out.print("Seleccione una opción: "); // Pide al usuario que seleccione una opción

                int opcion = scanner.nextInt(); // Lee la opción seleccionada por el usuario
                scanner.nextLine(); // Limpia el buffer del scanner

                switch (opcion) { // Comienza a ejecutar diferentes acciones basadas en la opción seleccionada

                    case 1: // Si el usuario elige "Añadir producto"
                        // Solicita al usuario que ingrese los detalles del nuevo producto
                        System.out.print("Ingrese el nombre del producto: ");
                        String nombre = scanner.nextLine();
                        System.out.print("Ingrese la fecha de envasado (YYYY-MM-DD): ");
                        String fechaEnvasado = scanner.nextLine();
                        System.out.print("Ingrese la cantidad de unidades: ");
                        int unidades = scanner.nextInt();
                        System.out.print("Ingrese el precio: ");
                        double precio = scanner.nextDouble();
                        scanner.nextLine(); // Limpia el buffer del scanner
                        System.out.print("¿Está disponible? (true/false): ");
                        boolean disponible = scanner.nextBoolean();
                        scanner.nextLine(); // Limpia el buffer del scanner

                        // Crea un nuevo objeto Producto con los detalles ingresados
                        Producto nuevoProducto = new Producto(nombre, fechaEnvasado, unidades, precio, disponible);
                        // Inserta el nuevo producto en la base de datos
                        boolean insercionExitosa = productoDAO.insertarProducto(nuevoProducto);
                        // Imprime un mensaje indicando si la inserción fue exitosa
                        if (insercionExitosa) {
                            System.out.println("Producto añadido correctamente.");
                        } else {
                            System.out.println("Error al añadir el producto.");
                        }
                        break;

                    case 2: // Si el usuario elige "Ver productos"
                        // Muestra todos los productos almacenados en la base de datos
                        System.out.println("\nProductos:");
                        productoDAO.mostrarProductos();
                        break;

                    case 3: // Si el usuario elige "Eliminar producto"
                        // Solicita al usuario que ingrese el ID del producto a eliminar
                        System.out.print("Ingrese el ID del producto a eliminar: ");
                        int idEliminar = scanner.nextInt();
                        // Intenta eliminar el producto de la base de datos
                        boolean eliminacionExitosa = productoDAO.eliminarProducto(idEliminar);
                        // Imprime un mensaje indicando si la eliminación fue exitosa
                        if (eliminacionExitosa) {
                            System.out.println("Producto eliminado correctamente.");
                        } else {
                            System.out.println("Error al eliminar el producto.");
                        }
                        break;

                    case 4: // Si el usuario elige "Actualizar producto"
                        // Solicita al usuario que ingrese el ID del producto a actualizar
                        System.out.print("Ingrese el ID del producto a actualizar: ");
                        int idActualizar = scanner.nextInt();
                        scanner.nextLine(); // Limpia el buffer del scanner

                        // Solicita al usuario que ingrese los nuevos detalles del producto
                        System.out.print("Ingrese el nuevo nombre del producto: ");
                        String nuevoNombre = scanner.nextLine();
                        System.out.print("Ingrese la nueva fecha de envasado (YYYY-MM-DD): ");
                        String nuevaFechaEnvasado = scanner.nextLine();
                        System.out.print("Ingrese la nueva cantidad de unidades: ");
                        int nuevasUnidades = scanner.nextInt();
                        System.out.print("Ingrese el nuevo precio: ");
                        double nuevoPrecio = scanner.nextDouble();
                        scanner.nextLine(); // Limpia el buffer del scanner
                        System.out.print("¿Está disponible? (true/false): ");
                        boolean nuevoDisponible = scanner.nextBoolean();
                        scanner.nextLine(); // Limpia el buffer del scanner

                        // Crea un nuevo objeto Producto con los nuevos detalles
                        Producto productoActualizado = new Producto(nuevoNombre, nuevaFechaEnvasado, nuevasUnidades, nuevoPrecio, nuevoDisponible);
                        productoActualizado.setIdProducto(idActualizar); // Establece el ID del producto a actualizar
                        // Actualiza el producto en la base de datos
                        boolean actualizacionExitosa = productoDAO.actualizarProducto(productoActualizado);
                        // Imprime un mensaje indicando si la actualización fue exitosa
                        if (actualizacionExitosa) {
                            System.out.println("Producto actualizado correctamente.");
                        } else {
                            System.out.println("Error al actualizar el producto.");
                        }
                        break;

                    case 5: // Si el usuario elige "Salir"
                        System.out.println("Saliendo del programa..."); // Imprime un mensaje de despedida
                        return; // Sale del bucle y termina el programa

                    default: // Si el usuario elige una opción inválida
                        System.out.println("Opción inválida."); // Imprime un mensaje de error
                }
            }

        } catch (SQLException e) { // Captura cualquier excepción de tipo SQLException
            e.printStackTrace(); // Imprime el seguimiento de la pila para identificar el error
        }
    }
}
