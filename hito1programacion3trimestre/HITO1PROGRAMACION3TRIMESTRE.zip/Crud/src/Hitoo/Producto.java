package Hitoo; // Define un paquete llamado Hitoo

public class Producto { // Define una clase llamada Producto

    // Atributos de la clase Producto
    private int idProducto; // El identificador único del producto
    private String nombre; // El nombre del producto
    private String fechaEnvasado; // La fecha en la que el producto fue envasado
    private int unidades; // El número de unidades disponibles
    private double precio; // El precio del producto
    private boolean disponible; // Indica si el producto está disponible o no

    // Constructor vacío
    public Producto() {}

    // Constructor con parámetros para inicializar los atributos
    public Producto(String nombre, String fechaEnvasado, int unidades, double precio, boolean disponible) {
        this.nombre = nombre; // Asigna el nombre del producto
        this.fechaEnvasado = fechaEnvasado; // Asigna la fecha de envasado del producto
        this.unidades = unidades; // Asigna el número de unidades disponibles del producto
        this.precio = precio; // Asigna el precio del producto
        this.disponible = disponible; // Asigna la disponibilidad del producto
    }

    // Métodos getters y setters para acceder y modificar los atributos de la clase

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFechaEnvasado() {
        return fechaEnvasado;
    }

    public void setFechaEnvasado(String fechaEnvasado) {
        this.fechaEnvasado = fechaEnvasado;
    }

    public int getUnidades() {
        return unidades;
    }

    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
}
