package Hitoo; // Define un paquete llamado Hitoo

import java.sql.*; // Importa las clases necesarias para interactuar con bases de datos SQL

public class ProductoDAO { // Define una clase llamada ProductoDAO

    private Connection con; // Establece una conexión a la base de datos

    public ProductoDAO(Connection con) { // Constructor que recibe una conexión como parámetro
        this.con = con; // Asigna la conexión a la variable de instancia
    }

    public boolean insertarProducto(Producto producto) { // Método para insertar un nuevo producto en la base de datos
        String query = "INSERT INTO productos (nombre, fechaEnvasado, unidades, precio, disponible) VALUES (?, ?, ?, ?, ?)"; // Consulta SQL para insertar un producto
        try (PreparedStatement stmt = con.prepareStatement(query)) { // Intenta preparar la consulta
            // Establece los valores de los parámetros en la consulta
            stmt.setString(1, producto.getNombre());
            stmt.setString(2, producto.getFechaEnvasado());
            stmt.setInt(3, producto.getUnidades());
            stmt.setDouble(4, producto.getPrecio());
            stmt.setBoolean(5, producto.isDisponible());
            int filasInsertadas = stmt.executeUpdate(); // Ejecuta la consulta y devuelve el número de filas afectadas
            return filasInsertadas > 0; // Devuelve true si se insertó al menos una fila, false en caso contrario
        } catch (SQLException e) { // Captura cualquier excepción de tipo SQLException
            e.printStackTrace(); // Imprime el seguimiento de la pila para identificar el error
            return false; // Devuelve false en caso de error
        }
    }

    public void mostrarProductos() { // Método para mostrar todos los productos almacenados en la base de datos
        String query = "SELECT * FROM productos"; // Consulta SQL para seleccionar todos los productos
        try (Statement stmt = con.createStatement(); // Crea un objeto Statement para ejecutar la consulta
             ResultSet rs = stmt.executeQuery(query)) { // Ejecuta la consulta y obtiene un conjunto de resultados
            while (rs.next()) { // Itera sobre cada fila del conjunto de resultados
                // Imprime los detalles de cada producto
                System.out.println("ID: " + rs.getInt("idProducto") +
                                   ", Nombre: " + rs.getString("nombre") +
                                   ", Fecha Envasado: " + rs.getString("fechaEnvasado") +
                                   ", Unidades: " + rs.getInt("unidades") +
                                   ", Precio: " + rs.getDouble("precio") +
                                   ", Disponible: " + rs.getBoolean("disponible"));
            }
        } catch (SQLException e) { // Captura cualquier excepción de tipo SQLException
            e.printStackTrace(); // Imprime el seguimiento de la pila para identificar el error
        }
    }

    public boolean eliminarProducto(int idProducto) { // Método para eliminar un producto de la base de datos por su ID
        String query = "DELETE FROM productos WHERE idProducto = ?"; // Consulta SQL para eliminar un producto
        try (PreparedStatement stmt = con.prepareStatement(query)) { // Intenta preparar la consulta
            stmt.setInt(1, idProducto); // Establece el valor del parámetro en la consulta
            int filasEliminadas = stmt.executeUpdate(); // Ejecuta la consulta y devuelve el número de filas afectadas
            return filasEliminadas > 0; // Devuelve true si se eliminó al menos una fila, false en caso contrario
        } catch (SQLException e) { // Captura cualquier excepción de tipo SQLException
            e.printStackTrace(); // Imprime el seguimiento de la pila para identificar el error
            return false; // Devuelve false en caso de error
        }
    }

    public boolean actualizarProducto(Producto producto) { // Método para actualizar un producto en la base de datos
        String query = "UPDATE productos SET nombre = ?, fechaEnvasado = ?, unidades = ?, precio = ?, disponible = ? WHERE idProducto = ?"; // Consulta SQL para actualizar un producto
        try (PreparedStatement stmt = con.prepareStatement(query)) { // Intenta preparar la consulta
            // Establece los valores de los parámetros en la consulta
            stmt.setString(1, producto.getNombre());
            stmt.setString(2, producto.getFechaEnvasado());
            stmt.setInt(3, producto.getUnidades());
            stmt.setDouble(4, producto.getPrecio());
            stmt.setBoolean(5, producto.isDisponible());
            stmt.setInt(6, producto.getIdProducto());
            int filasActualizadas = stmt.executeUpdate(); // Ejecuta la consulta y devuelve el número de filas afectadas
            return filasActualizadas > 0; // Devuelve true si se actualizó al menos una fila, false en caso contrario
        } catch (SQLException e) { // Captura cualquier excepción de tipo SQLException
            e.printStackTrace(); // Imprime el seguimiento de la pila para identificar el error
            return false; // Devuelve false en caso de error
        }
    }
}
