package Actividad1;

public class Menu {
    public static void main(String[] args) {
        Perro miPerro = new Perro();
        miPerro.comer(); 
        miPerro.ladrar();
    }
}