package Actividad1;

class Animal {
    void comer() {
        System.out.println("El animal está comiendo");
    }
}
