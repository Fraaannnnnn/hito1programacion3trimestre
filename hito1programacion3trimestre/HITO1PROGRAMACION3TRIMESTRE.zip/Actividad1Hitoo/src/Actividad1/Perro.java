package Actividad1;

class Perro extends Animal {
    void ladrar() {
        System.out.println("El perro está ladrando...");
    }
}